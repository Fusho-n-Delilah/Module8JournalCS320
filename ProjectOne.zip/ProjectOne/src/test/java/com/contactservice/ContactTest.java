/**
 * ContactTest.java
 * Description: Unit tests for Contact class.
 * Author: Alec Feldhaus
 * Date: 2024-02-07
 */

package com.contactservice;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class ContactTest {

    @Test
    public void construct_validParameters_succeeds() {
        String id = "1234567890";
        String name = "ABCDEFGHIJ";
        String phone = "0123456789";
        String addr = "123456789012345678901234567890";
        Contact c = new Contact(id, name, name, phone, addr);
        assertEquals(id, c.getContactId());
        assertEquals(name, c.getFirstName());
        assertEquals(name, c.getLastName());
        assertEquals(phone, c.getPhone());
        assertEquals(addr, c.getAddress());
    }

    @Test
    public void construct_nullId_throws() {
        assertThrows(IllegalArgumentException.class, () -> new Contact(null, "A", "B", "0123456789", "Addr"));
    }

    @Test
    public void construct_emptyFirstName_throws() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("id", "", "B", "0123456789", "Addr"));
    }

    @Test
    public void construct_phoneInvalid_throws() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("id", "A", "B", "123", "Addr"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("id", "A", "B", "abcdefghij", "Addr"));
    }

    @Test
    public void setters_validate_and_trim() {
        Contact c = new Contact("i1", "One", "Two", "0123456789", "Addr");
        c.setFirstName("  Tom  ");
        assertEquals("Tom", c.getFirstName());
        c.setAddress("  123 Road  ");
        assertEquals("123 Road", c.getAddress());
    }

    @Test
    public void construct_idTooLong_throws() {
        String id = "12345678901";
        assertThrows(IllegalArgumentException.class, () -> new Contact(id, "A", "B", "0123456789", "Addr"));
    }

    @Test
    public void construct_firstNameTooLong_throws() {
        String name = "ABCDEFGHIJK";
        assertThrows(IllegalArgumentException.class, () -> new Contact("id", name, "B", "0123456789", "Addr"));
    }

    @Test
    public void construct_lastNameTooLong_throws() {
        String name = "ABCDEFGHIJK";
        assertThrows(IllegalArgumentException.class, () -> new Contact("id", "A", name, "0123456789", "Addr"));
    }

    @Test
    public void construct_addressTooLong_throws() {
        String addr = "1234567890123456789012345678901";
        assertThrows(IllegalArgumentException.class, () -> new Contact("id", "A", "B", "0123456789", addr));
    }

    @Test
    public void construct_whitespaceId_throws() {
        assertThrows(IllegalArgumentException.class, () -> new Contact("   ", "A", "B", "0123456789", "Addr"));
    }

    @Test
    public void construct_trims_inputs_succeeds() {
        Contact c = new Contact(" id2 ", "  Tom  ", "  Smith  ", " 0123456789 ", "  456 Road  ");
        // Note: constructor validates id but does not trim it when storing; other fields are trimmed via setters
        assertEquals(" id2 ", c.getContactId());
        assertEquals("Tom", c.getFirstName());
        assertEquals("Smith", c.getLastName());
        assertEquals("0123456789", c.getPhone());
        assertEquals("456 Road", c.getAddress());
    }

    @Test
    public void contactId_isImmutable() {
        Contact c = new Contact("immutable", "A", "B", "0123456789", "Addr");
        c.setFirstName("New");
        assertEquals("immutable", c.getContactId());
    }

    @Test
    public void construct_nullParameters_throws() {
        // Each required parameter must be not be null
        assertThrows(IllegalArgumentException.class, () -> new Contact("id", null, "B", "0123456789", "Addr"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("id", "A", null, "0123456789", "Addr"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("id", "A", "B", null, "Addr"));
        assertThrows(IllegalArgumentException.class, () -> new Contact("id", "A", "B", "0123456789", null));
    }
    
    @Test
    public void equals_sameObject_returnsTrue() {
        Contact contact = new Contact("id1", "John", "Doe", "0123456789", "123 Main St");
        assertEquals(contact, contact);
    }
    
    @Test
    public void equals_identicalContacts_returnsTrue() {
        Contact contact1 = new Contact("id1", "John", "Doe", "0123456789", "123 Main St");
        Contact contact2 = new Contact("id1", "John", "Doe", "0123456789", "123 Main St");
        assertEquals(contact1, contact2);
    }
    
    @Test
    public void equals_differentId_returnsFalse() {
        Contact contact1 = new Contact("id1", "John", "Doe", "0123456789", "123 Main St");
        Contact contact2 = new Contact("id2", "John", "Doe", "0123456789", "123 Main St");
        assertNotEquals(contact1, contact2);
    }
    
    @Test
    public void equals_differentFirstName_returnsFalse() {
        Contact contact1 = new Contact("id1", "John", "Doe", "0123456789", "123 Main St");
        Contact contact2 = new Contact("id1", "Jane", "Doe", "0123456789", "123 Main St");
        assertNotEquals(contact1, contact2);
    }
    
    @Test
    public void equals_differentLastName_returnsFalse() {
        Contact contact1 = new Contact("id1", "John", "Doe", "0123456789", "123 Main St");
        Contact contact2 = new Contact("id1", "John", "Smith", "0123456789", "123 Main St");
        assertNotEquals(contact1, contact2);
    }
    
    @Test
    public void equals_differentPhone_returnsFalse() {
        Contact contact1 = new Contact("id1", "John", "Doe", "0123456789", "123 Main St");
        Contact contact2 = new Contact("id1", "John", "Doe", "9876543210", "123 Main St");
        assertNotEquals(contact1, contact2);
    }
    
    @Test
    public void equals_differentAddress_returnsFalse() {
        Contact contact1 = new Contact("id1", "John", "Doe", "0123456789", "123 Main St");
        Contact contact2 = new Contact("id1", "John", "Doe", "0123456789", "456 Oak Ave");
        assertNotEquals(contact1, contact2);
    }
    
    @Test
    public void equals_nullObject_returnsFalse() {
        Contact contact = new Contact("id1", "John", "Doe", "0123456789", "123 Main St");
        assertNotEquals(contact, null);
    }
    
    @Test
    public void equals_differentType_returnsFalse() {
        Contact contact = new Contact("id1", "John", "Doe", "0123456789", "123 Main St");
        assertNotEquals(contact, "Not a Contact");
    }
    
    @Test
    public void hashCode_identicalContacts_sameHashCode() {
        Contact contact1 = new Contact("id1", "John", "Doe", "0123456789", "123 Main St");
        Contact contact2 = new Contact("id1", "John", "Doe", "0123456789", "123 Main St");
        assertEquals(contact1.hashCode(), contact2.hashCode());
    }
    
    @Test
    public void hashCode_differentContacts_likelyDifferentHashCode() {
        Contact contact1 = new Contact("id1", "John", "Doe", "0123456789", "123 Main St");
        Contact contact2 = new Contact("id2", "Jane", "Smith", "9876543210", "456 Oak Ave");
        // While hash codes could theoretically collide, different objects should likely have different codes
        assertNotEquals(contact1.hashCode(), contact2.hashCode());
    }
    
    @Test
    public void hashCode_sameObjectMultipleCalls_consistentHashCode() {
        Contact contact = new Contact("id1", "John", "Doe", "0123456789", "123 Main St");
        int hashCode1 = contact.hashCode();
        int hashCode2 = contact.hashCode();
        assertEquals(hashCode1, hashCode2);
    }
}
