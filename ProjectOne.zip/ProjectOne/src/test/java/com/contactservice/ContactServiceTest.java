/**
 * ContactServiceTest.java
 * Description: Unit tests for ContactService.
 * Author: Alec Feldhaus
 * Date: 2024-02-07
 */

package com.contactservice;

import static org.junit.jupiter.api.Assertions.*;

import java.util.NoSuchElementException;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class ContactServiceTest {

    private ContactService service;

    @BeforeEach
    public void setUp() {
        service = new ContactService();
    }

    @Test
    public void addContact_validContact_added() {
        Contact c = new Contact("id1", "John", "Doe", "0123456789", "123 Main St");
        service.addContact(c);
        assertEquals(c, service.getContact("id1"));
    }

    @Test
    public void addContact_duplicateId_throws() {
        Contact c1 = new Contact("dup", "A", "B", "0123456789", "Addr");
        Contact c2 = new Contact("dup", "X", "Y", "0123456789", "Addr2");
        service.addContact(c1);
        assertThrows(IllegalArgumentException.class, () -> service.addContact(c2));
    }

    @Test
    public void deleteContact_existing_removes() {
        Contact c = new Contact("toDel", "Jane", "Doe", "1112223333", "Somewhere");
        service.addContact(c);
        service.deleteContact("toDel");
        assertNull(service.getContact("toDel"));
    }

    @Test
    public void deleteContact_missing_throws() {
        assertThrows(NoSuchElementException.class, () -> service.deleteContact("nope"));
    }

    @Test
    public void updateContact_allFields_updated() {
        Contact c = new Contact("u1", "First", "Last", "0001112222", "Addr1");
        service.addContact(c);
        service.updateContact("u1", "NewFirst", "NewLast", "9998887777", "NewAddr");
        Contact updated = service.getContact("u1");
        assertEquals("NewFirst", updated.getFirstName());
        assertEquals("NewLast", updated.getLastName());
        assertEquals("9998887777", updated.getPhone());
        assertEquals("NewAddr", updated.getAddress());
    }

    @Test
    public void updateContact_invalidPhone_throws() {
        Contact c = new Contact("u2", "F", "L", "1234567890", "Apt");
        service.addContact(c);

        assertThrows(IllegalArgumentException.class, () -> service.updateContact("u2", "F", "L", "123", "Apt"));
    }

    @Test
    public void updateContact_invalidPhone_nonnumeric_throws() {
        Contact c = new Contact("u2b", "F", "L", "1234567890", "Apt");
        service.addContact(c);
 
        assertThrows(IllegalArgumentException.class, () -> service.updateContact("u2b", "F", "L", "abcdefghij", "Apt"));
    }

    @Test
    public void updateContact_invalidFirstName_throws() {
        Contact c = new Contact("u2c", "First", "Last", "1234567890", "Apt");
        service.addContact(c);
        // empty or whitespace-only names are invalid
        assertThrows(IllegalArgumentException.class, () -> service.updateContact("u2c", "", "Last", "1234567890", "Apt"));
        assertThrows(IllegalArgumentException.class, () -> service.updateContact("u2c", "   ", "Last", "1234567890", "Apt"));
        // too long (more than 10)
        String longFirst = "ABCDEFGHIJK"; // 11 chars
        assertThrows(IllegalArgumentException.class, () -> service.updateContact("u2c", longFirst, "Last", "1234567890", "Apt"));
    }

    @Test
    public void updateContact_invalidLastName_throws() {
        Contact c = new Contact("u2d", "First", "Last", "1234567890", "Apt");
        service.addContact(c);
        assertThrows(IllegalArgumentException.class, () -> service.updateContact("u2d", "First", "", "1234567890", "Apt"));
        assertThrows(IllegalArgumentException.class, () -> service.updateContact("u2d", "First", "   ", "1234567890", "Apt"));
        String longLast = "ABCDEFGHIJK"; // 11 chars
        assertThrows(IllegalArgumentException.class, () -> service.updateContact("u2d", "First", longLast, "1234567890", "Apt"));
    }

    @Test
    public void updateContact_invalidAddress_throws() {
        Contact c = new Contact("u2e", "First", "Last", "1234567890", "Apt");
        service.addContact(c);
        assertThrows(IllegalArgumentException.class, () -> service.updateContact("u2e", "First", "Last", "1234567890", ""));
        assertThrows(IllegalArgumentException.class, () -> service.updateContact("u2e", "First", "Last", "1234567890", "   "));
        String longAddr = new String(new char[31]).replace('\0', 'x');
        assertEquals(31, longAddr.length());
        assertThrows(IllegalArgumentException.class, () -> service.updateContact("u2e", "First", "Last", "1234567890", longAddr));
    }

    @Test
    public void updateContact_nullId_throws() {
        assertThrows(IllegalArgumentException.class, () -> service.updateContact(null, "A", "B", "0123456789", "Addr"));
    }

    @Test
    public void updateContact_missingId_throws() {
        assertThrows(NoSuchElementException.class, () -> service.updateContact("missing", "A", "B", "0123456789", "Addr"));
    }

    @Test
    public void addContact_null_throws() {
        assertThrows(IllegalArgumentException.class, () -> service.addContact(null));
    }

    @Test
    public void deleteContact_null_throws() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteContact(null));
    }

    @Test
    public void updateContact_nullFirstName_keepsOriginal() {
        Contact c = new Contact("u3", "F", "L", "1234567890", "Apt");
        service.addContact(c);
        service.updateContact("u3", null, "L2", "1234567890", "Apt2");
        Contact updated = service.getContact("u3");
        assertEquals("F", updated.getFirstName());
        assertEquals("L2", updated.getLastName());
        assertEquals("1234567890", updated.getPhone());
        assertEquals("Apt2", updated.getAddress());
    }

    @Test
    public void updateContact_nullLastName_keepsOriginal() {
        Contact c = new Contact("u4", "F4", "L4", "0123456789", "Addr4");
        service.addContact(c);
        service.updateContact("u4", "F4-new", null, "0123456789", "Addr4-new");
        Contact updated = service.getContact("u4");
        assertEquals("F4-new", updated.getFirstName());
        assertEquals("L4", updated.getLastName());
        assertEquals("0123456789", updated.getPhone());
        assertEquals("Addr4-new", updated.getAddress());
    }

    @Test
    public void updateContact_nullPhone_keepsOriginal() {
        Contact c = new Contact("u5", "F5", "L5", "1112223333", "Addr5");
        service.addContact(c);
        service.updateContact("u5", "F5-new", "L5-new", null, "Addr5-new");
        Contact updated = service.getContact("u5");
        assertEquals("F5-new", updated.getFirstName());
        assertEquals("L5-new", updated.getLastName());
        assertEquals("1112223333", updated.getPhone());
        assertEquals("Addr5-new", updated.getAddress());
    }

    @Test
    public void updateContact_nullAddress_keepsOriginal() {
        Contact c = new Contact("u6", "F6", "L6", "2223334444", "Addr6");
        service.addContact(c);
        service.updateContact("u6", "F6-new", "L6-new", "2223334444", null);
        Contact updated = service.getContact("u6");
        assertEquals("F6-new", updated.getFirstName());
        assertEquals("L6-new", updated.getLastName());
        assertEquals("2223334444", updated.getPhone());
        assertEquals("Addr6", updated.getAddress());
    }

    @Test
    public void updateContact_multipleNulls_partialUpdateWorks() {
        Contact c = new Contact("u7", "F7", "L7", "3334445555", "Addr7");
        service.addContact(c);
        // change firstName and address, leave lastName and phone unchanged
        service.updateContact("u7", "F7-new", null, null, "Addr7-new");
        Contact updated = service.getContact("u7");
        assertEquals("F7-new", updated.getFirstName());
        assertEquals("L7", updated.getLastName());
        assertEquals("3334445555", updated.getPhone());
        assertEquals("Addr7-new", updated.getAddress());
    }
}
