/**
 * TaskTest.java
 * Description: Unit tests for Task class.
 * Author: Alec Feldhaus
 * Date: 2024-02-07
 */

package com.taskservice;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

public class TaskTest {

    @Test
    public void construct_validParameters_succeeds() {
        Task t = new Task("id1", "Name", "Description");
        assertEquals("id1", t.getTaskId());
        assertEquals("Name", t.getName());
        assertEquals("Description", t.getDescription());
    }

    @Test
    public void construct_nullId_throws() {
        assertThrows(IllegalArgumentException.class, () -> new Task(null, "N", "D"));
    }

    @Test
    public void construct_whitespaceId_throws() {
        assertThrows(IllegalArgumentException.class, () -> new Task("   ", "N", "D"));
    }

    @Test
    public void construct_idTooLong_throws() {
        String id = new String(new char[11]).replace('\0', 'x');
        assertEquals(11, id.length());
        assertThrows(IllegalArgumentException.class, () -> new Task(id, "N", "D"));
    }

    @Test
    public void validateId_trims_and_returns() {
        Task t = new Task("i1", "N", "D");
        assertEquals("abc", t.validateId("  abc  "));
    }

    @Test
    public void construct_nullName_throws() {
        assertThrows(IllegalArgumentException.class, () -> new Task("i2", null, "D"));
    }

    @Test
    public void construct_nullDescription_throws() {
        assertThrows(IllegalArgumentException.class, () -> new Task("i3", "N", null));
    }

    @Test
    public void setName_valid_and_preserves_whitespace() {
        Task t = new Task("i4", "Name", "Desc");
        t.setName("  Tom  ");
        // Implementation validates trimmed content but stores original string
        assertEquals("  Tom  ", t.getName());
    }

    @Test
    public void setName_null_throws() {
        Task t = new Task("i5", "N", "D");
        assertThrows(IllegalArgumentException.class, () -> t.setName(null));
    }

    @Test
    public void setName_emptyOrTooLong_throws() {
        Task t = new Task("i6", "N", "D");
        assertThrows(IllegalArgumentException.class, () -> t.setName(""));
        assertThrows(IllegalArgumentException.class, () -> t.setName("   ")); // whitespace only
        String longName = new String(new char[21]).replace('\0', 'x');
        assertEquals(21, longName.length());
        assertThrows(IllegalArgumentException.class, () -> t.setName(longName));
    }

    @Test
    public void setDescription_valid_and_preserves_whitespace() {
        Task t = new Task("i7", "N", "D");
        t.setDescription("  Some Desc  ");
        assertEquals("  Some Desc  ", t.getDescription());
    }

    @Test
    public void setDescription_null_throws() {
        Task t = new Task("i8", "N", "D");
        assertThrows(IllegalArgumentException.class, () -> t.setDescription(null));
    }

    @Test
    public void setDescription_emptyOrTooLong_throws() {
        Task t = new Task("i9", "N", "D");
        assertThrows(IllegalArgumentException.class, () -> t.setDescription(""));
        assertThrows(IllegalArgumentException.class, () -> t.setDescription("   ")); // whitespace only
        String longDesc = new String(new char[51]).replace('\0', 'x');
        assertEquals(51, longDesc.length());
        assertThrows(IllegalArgumentException.class, () -> t.setDescription(longDesc));
    }

    @Test
    public void boundary_lengths_allowed_and_rejected() {
        // id exactly 10 allowed
        String id10 = new String(new char[10]).replace('\0', 'i');
        Task t10 = new Task(id10, "N", "D");
        assertEquals(id10, t10.getTaskId());

        // name exactly 20 allowed
        String name20 = new String(new char[20]).replace('\0', 'n');
        Task tn = new Task("id20", name20, "D");
        assertEquals(name20, tn.getName());

        // description exactly 50 allowed
        String desc50 = new String(new char[50]).replace('\0', 'd');
        Task td = new Task("id50", "N", desc50);
        assertEquals(desc50, td.getDescription());
    }
    
    @Test
    public void equals_sameObject_returnsTrue() {
        Task task = new Task("id1", "Name", "Description");
        assertEquals(task, task);
    }
    
    @Test
    public void equals_identicalTasks_returnsTrue() {
        Task task1 = new Task("id1", "Name", "Description");
        Task task2 = new Task("id1", "Name", "Description");
        assertEquals(task1, task2);
    }
    
    @Test
    public void equals_differentId_returnsFalse() {
        Task task1 = new Task("id1", "Name", "Description");
        Task task2 = new Task("id2", "Name", "Description");
        assertNotEquals(task1, task2);
    }
    
    @Test
    public void equals_differentName_returnsFalse() {
        Task task1 = new Task("id1", "Name", "Description");
        Task task2 = new Task("id1", "OtherName", "Description");
        assertNotEquals(task1, task2);
    }
    
    @Test
    public void equals_differentDescription_returnsFalse() {
        Task task1 = new Task("id1", "Name", "Description");
        Task task2 = new Task("id1", "Name", "OtherDescription");
        assertNotEquals(task1, task2);
    }
    
    @Test
    public void equals_nullObject_returnsFalse() {
        Task task = new Task("id1", "Name", "Description");
        assertNotEquals(task, null);
    }
    
    @Test
    public void equals_differentType_returnsFalse() {
        Task task = new Task("id1", "Name", "Description");
        assertNotEquals(task, "Not a Task");
    }
    
    @Test
    public void hashCode_identicalTasks_sameHashCode() {
        Task task1 = new Task("id1", "Name", "Description");
        Task task2 = new Task("id1", "Name", "Description");
        assertEquals(task1.hashCode(), task2.hashCode());
    }
    
    @Test
    public void hashCode_differentTasks_likelyDifferentHashCode() {
        Task task1 = new Task("id1", "Name", "Description");
        Task task2 = new Task("id2", "OtherName", "OtherDescription");
        // While hash codes could theoretically collide, different objects should likely have different codes
        assertNotEquals(task1.hashCode(), task2.hashCode());
    }
    
    @Test
    public void hashCode_sameObjectMultipleCalls_consistentHashCode() {
        Task task = new Task("id1", "Name", "Description");
        int hashCode1 = task.hashCode();
        int hashCode2 = task.hashCode();
        assertEquals(hashCode1, hashCode2);
    }
}
