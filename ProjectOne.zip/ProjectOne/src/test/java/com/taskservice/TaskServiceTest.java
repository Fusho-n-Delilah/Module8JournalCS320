/**
 * TaskServiceTest.java
 * Description: Unit tests for TaskService.
 * Author: Alec Feldhaus
 * Date: 2024-02-07
 */

package com.taskservice;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

public class TaskServiceTest {

    private TaskService service;

    @BeforeEach
    public void setUp() {
        service = new TaskService();
    }

    @Test
    public void addTask_validTask_added() {
        Task t = new Task("t1", "Name", "Description");
        service.addTask(t);
        assertEquals(t, service.getTask("t1"));
    }

    @Test
    public void addTask_null_throws() {
        assertThrows(IllegalArgumentException.class, () -> service.addTask(null));
    }

    @Test
    public void addTask_duplicateId_throws() {
        Task t1 = new Task("dup", "A", "B");
        service.addTask(t1);
        Task t2 = new Task("dup", "X", "Y");
        assertThrows(IllegalArgumentException.class, () -> service.addTask(t2));
    }

    @Test
    public void deleteTask_existing_removes() {
        Task t = new Task("toDel", "N", "D");
        service.addTask(t);
        service.deleteTask("toDel");
        assertNull(service.getTask("toDel"));
    }

    @Test
    public void deleteTask_missing_throws() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteTask("nope"));
    }

    @Test
    public void deleteTask_null_throws() {
        assertThrows(IllegalArgumentException.class, () -> service.deleteTask(null));
    }

    @Test
    public void updateTask_allFields_updated() {
        Task t = new Task("u1", "First", "Desc1");
        service.addTask(t);
        service.updateTask("u1", "NewFirst", "NewDesc");
        Task updated = service.getTask("u1");
        assertEquals("NewFirst", updated.getName());
        assertEquals("NewDesc", updated.getDescription());
    }

    @Test
    public void updateTask_nullName_leavesName() {
        Task t = new Task("u2", "Name2", "Desc2");
        service.addTask(t);
        service.updateTask("u2", null, "ChangedDesc");
        Task updated = service.getTask("u2");
        assertEquals("Name2", updated.getName());
        assertEquals("ChangedDesc", updated.getDescription());
    }

    @Test
    public void updateTask_nullDescription_leavesDescription() {
        Task t = new Task("u3", "Name3", "Desc3");
        service.addTask(t);
        service.updateTask("u3", "ChangedName", null);
        Task updated = service.getTask("u3");
        assertEquals("ChangedName", updated.getName());
        assertEquals("Desc3", updated.getDescription());
    }

    @Test
    public void updateTask_invalidName_throws() {
        Task t = new Task("u4", "N", "D");
        service.addTask(t);
        assertThrows(IllegalArgumentException.class, () -> service.updateTask("u4", "", "D"));
        String longName = "xxxxxxxxxxxxxxxxxxxxx"; // 21 chars
        assertThrows(IllegalArgumentException.class, () -> service.updateTask("u4", longName, "D"));
    }

    @Test
    public void updateTask_invalidDescription_throws() {
        Task t = new Task("u5", "N", "D");
        service.addTask(t);
        assertThrows(IllegalArgumentException.class, () -> service.updateTask("u5", "N", ""));
        String longDesc = new String(new char[51]).replace('\0', 'x');
        assertThrows(IllegalArgumentException.class, () -> service.updateTask("u5", "N", longDesc));
    }

    @Test
    public void updateTask_missingId_throws() {
        assertThrows(IllegalArgumentException.class, () -> service.updateTask("missing", "a", "b"));
    }

    @Test
    public void updateTask_nullId_throws() {
        assertThrows(IllegalArgumentException.class, () -> service.updateTask(null, "a", "b"));
    }
}

