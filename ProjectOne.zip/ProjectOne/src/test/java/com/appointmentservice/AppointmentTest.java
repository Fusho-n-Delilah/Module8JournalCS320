/**
 * AppointmentTest.java
 * Description: Unit tests for Appointment class.
 * Author: Alec Feldhaus
 * Date: 2024-02-07
 */

package com.appointmentservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Date;

public class AppointmentTest {
    
    private final Long ONE_DAY_IN_MILLIS = 1000L * 60 * 60 * 24;
    private Date futureDate;
    private Date pastDate;
    private String validId;
    private String validDescription;
    
    /**
     * setUp() - Initializes common test data before each test method runs.
      * Creates a future date, a past date, and valid strings for appointmentId and description.
      * Note: The test usese System time and millisoconds to create Dates, this is a more reliable way to work with
      * the java date class in tests and avoid issues with timezones and formatting.
     */
    @BeforeEach
    public void setUp() {


        // Create a future date 1 day ahead of current system date/time
        futureDate = new Date(System.currentTimeMillis() + ONE_DAY_IN_MILLIS);
        
        // Create a past date 1 day previous to current system date/time
        pastDate = new Date(System.currentTimeMillis() - ONE_DAY_IN_MILLIS);
        
        validId = "APT001";
        validDescription = "Team meeting";
    }
    
    @Test
    public void construct_validInput_succeeds() {
        Appointment appointment = new Appointment(validId, futureDate, validDescription);
        assertEquals(validId, appointment.getAppointmentId());
        assertEquals(futureDate, appointment.getDate());
        assertEquals(validDescription, appointment.getDescription());
    }
    
    @Test
    public void construct_nullAppointmentId_throws() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(null, futureDate, validDescription);
        });
        assertEquals("appointmentId must not be null", exception.getMessage());
    }
    
    @Test
    public void construct_emptyAppointmentId_throws() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("", futureDate, validDescription);
        });
        assertEquals("appointmentId is required", exception.getMessage());
    }
    
    @Test
    public void construct_whitespaceOnlyAppointmentId_throws() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("   ", futureDate, validDescription);
        });
        assertEquals("appointmentId is required", exception.getMessage());
    }
    
    @Test
    public void construct_appointmentIdTooLong_throws() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment("APT001TOOLONG", futureDate, validDescription);
        });
        assertEquals("appointmentId must be less than 10 characters", exception.getMessage());
    }
    
    @Test
    public void construct_nullDate_throws() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(validId, null, validDescription);
        });
        assertEquals("date must not be null", exception.getMessage());
    }
    
    @Test
    public void construct_pastDate_throws() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(validId, pastDate, validDescription);
        });
        assertEquals("date must be in the future", exception.getMessage());
    }
    
    @Test
    public void construct_nullDescription_throws() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(validId, futureDate, null);
        });
        assertEquals("description must not be null", exception.getMessage());
    }
    
    @Test
    public void construct_emptyDescription_throws() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(validId, futureDate, "");
        });
        assertEquals("description is required", exception.getMessage());
    }
    
    @Test
    public void construct_whitespaceOnlyDescription_throws() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(validId, futureDate, "   ");
        });
        assertEquals("description is required", exception.getMessage());
    }
    
    @Test
    public void construct_descriptionTooLong_throws() {
        String longDescription = "This is a very long description that exceeds the fifty character limit";
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            new Appointment(validId, futureDate, longDescription);
        });
        assertEquals("description must be less than 50 characters", exception.getMessage());
    }
    
    @Test
    public void getAppointmentId_returns_appointmentId() {
        Appointment appointment = new Appointment(validId, futureDate, validDescription);
        assertEquals(validId, appointment.getAppointmentId());
    }
    
    @Test
    public void getDate_returns_date() {
        Appointment appointment = new Appointment(validId, futureDate, validDescription);
        assertEquals(futureDate, appointment.getDate());
    }
    
    @Test
    public void getDescription_returns_description() {
        Appointment appointment = new Appointment(validId, futureDate, validDescription);
        assertEquals(validDescription, appointment.getDescription());
    }
    
    @Test
    public void validateId_validId_succeeds() {
        Appointment appointment = new Appointment(validId, futureDate, validDescription);
        String result = appointment.validateId("TEST01");
        assertEquals("TEST01", result);
    }
    
    @Test
    public void validateId_withLeadingAndTrailingSpaces_trims() {
        Appointment appointment = new Appointment(validId, futureDate, validDescription);
        String result = appointment.validateId("  TEST01  ");
        assertEquals("TEST01", result);
    }
    
    @Test
    public void validateId_null_throws() {
        Appointment appointment = new Appointment(validId, futureDate, validDescription);
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            appointment.validateId(null);
        });
        assertEquals("appointmentId must not be null", exception.getMessage());
    }
    
    @Test
    public void validateId_empty_throws() {
        Appointment appointment = new Appointment(validId, futureDate, validDescription);
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            appointment.validateId("");
        });
        assertEquals("appointmentId is required", exception.getMessage());
    }
    
    @Test
    public void validateId_tooLong_throws() {
        Appointment appointment = new Appointment(validId, futureDate, validDescription);
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            appointment.validateId("APT001TOOLONG");
        });
        assertEquals("appointmentId must be less than 10 characters", exception.getMessage());
    }
    
    @Test
    public void setDate_validFutureDate_succeeds() {
        Appointment appointment = new Appointment(validId, futureDate, validDescription);
        Date newFutureDate = new Date(System.currentTimeMillis() + (1000 * 60 * 60 * 48));
        
        appointment.setDate(newFutureDate);
        assertEquals(newFutureDate, appointment.getDate());
    }
    
    @Test
    public void setDate_null_throws() {
        Appointment appointment = new Appointment(validId, futureDate, validDescription);
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            appointment.setDate(null);
        });
        assertEquals("date must not be null", exception.getMessage());
    }
    
    @Test
    public void setDate_past_throws() {
        Appointment appointment = new Appointment(validId, futureDate, validDescription);
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            appointment.setDate(pastDate);
        });
        assertEquals("date must be in the future", exception.getMessage());
    }
    
    @Test
    public void setDate_validDate_updates() {
        Appointment appointment = new Appointment(validId, futureDate, validDescription);
        Date newDate = new Date(System.currentTimeMillis() + (1000 * 60 * 60 * 72));
        
        appointment.setDate(newDate);
        assertEquals(newDate, appointment.getDate());
    }

    @Test
    public void setDescription_validDescription_succeeds() {
        Appointment appointment = new Appointment(validId, futureDate, validDescription);
        String newDescription = "Updated meeting";
        
        appointment.setDescription(newDescription);
        assertEquals(newDescription, appointment.getDescription());
    }
    
    @Test
    public void setDescription_null_throws() {
        Appointment appointment = new Appointment(validId, futureDate, validDescription);
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            appointment.setDescription(null);
        });
        assertEquals("description must not be null", exception.getMessage());
    }
    
    @Test
    public void setDescription_empty_throws() {
        Appointment appointment = new Appointment(validId, futureDate, validDescription);
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            appointment.setDescription("");
        });
        assertEquals("description is required", exception.getMessage());
    }
    
    @Test
    public void setDescription_whitespaceOnly_throws() {
        Appointment appointment = new Appointment(validId, futureDate, validDescription);
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            appointment.setDescription("   ");
        });
        assertEquals("description is required", exception.getMessage());
    }
    
    @Test
    public void setDescription_tooLong_throws() {
        Appointment appointment = new Appointment(validId, futureDate, validDescription);
        String longDescription = "This is a very long description that exceeds the fifty character limit";
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            appointment.setDescription(longDescription);
        });
        assertEquals("description must be less than 50 characters", exception.getMessage());
    }
    
    @Test
    public void setDescription_validDescription_updates() {
        Appointment appointment = new Appointment(validId, futureDate, validDescription);
        String newDescription = "Doctor appointment";
        
        appointment.setDescription(newDescription);
        assertEquals(newDescription, appointment.getDescription());
    }
    
    @Test
    public void equals_sameObject_returnsTrue() {
        Appointment appointment = new Appointment(validId, futureDate, validDescription);
        assertEquals(appointment, appointment);
    }
    
    @Test
    public void equals_identicalAppointments_returnsTrue() {
        Appointment appointment1 = new Appointment(validId, futureDate, validDescription);
        Appointment appointment2 = new Appointment(validId, futureDate, validDescription);
        assertEquals(appointment1, appointment2);
    }
    
    @Test
    public void equals_differentId_returnsFalse() {
        Appointment appointment1 = new Appointment(validId, futureDate, validDescription);
        Appointment appointment2 = new Appointment("APT002", futureDate, validDescription);
        assertNotEquals(appointment1, appointment2);
    }
    
    @Test
    public void equals_differentDate_returnsFalse() {
        Appointment appointment1 = new Appointment(validId, futureDate, validDescription);
        Date differentDate = new Date(System.currentTimeMillis() + (1000L * 60 * 60 * 48));
        Appointment appointment2 = new Appointment(validId, differentDate, validDescription);
        assertNotEquals(appointment1, appointment2);
    }
    
    @Test
    public void equals_differentDescription_returnsFalse() {
        Appointment appointment1 = new Appointment(validId, futureDate, validDescription);
        Appointment appointment2 = new Appointment(validId, futureDate, "Different meeting");
        assertNotEquals(appointment1, appointment2);
    }
    
    @Test
    public void equals_nullObject_returnsFalse() {
        Appointment appointment = new Appointment(validId, futureDate, validDescription);
        assertNotEquals(appointment, null);
    }
    
    @Test
    public void equals_differentType_returnsFalse() {
        Appointment appointment = new Appointment(validId, futureDate, validDescription);
        assertNotEquals(appointment, "Not an Appointment");
    }
    
    @Test
    public void hashCode_identicalAppointments_samHashCode() {
        Appointment appointment1 = new Appointment(validId, futureDate, validDescription);
        Appointment appointment2 = new Appointment(validId, futureDate, validDescription);
        assertEquals(appointment1.hashCode(), appointment2.hashCode());
    }
    
    @Test
    public void hashCode_differentAppointments_likelyDifferentHashCode() {
        Appointment appointment1 = new Appointment(validId, futureDate, validDescription);
        Appointment appointment2 = new Appointment("APT002", futureDate, validDescription);
        // While hash codes could theoretically collide, different objects should likely have different codes
        assertNotEquals(appointment1.hashCode(), appointment2.hashCode());
    }
    
    @Test
    public void hashCode_sameObjectMultipleCalls_consistentHashCode() {
        Appointment appointment = new Appointment(validId, futureDate, validDescription);
        int hashCode1 = appointment.hashCode();
        int hashCode2 = appointment.hashCode();
        assertEquals(hashCode1, hashCode2);
    }
}
