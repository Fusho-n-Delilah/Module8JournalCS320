/**
 * AppointmentServiceTest.java
 * Description: Unit tests for AppointmentService.
 * Author: Alec Feldhaus
 * Date: 2024-02-07
 */

package com.appointmentservice;

import static org.junit.jupiter.api.Assertions.*;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import java.util.Date;

public class AppointmentServiceTest {
    
    private final Long ONE_DAY_IN_MILLIS = 1000L * 60 * 60 * 24;
    private AppointmentService service;
    private Date futureDate;
    private Date pastDate;
    private String validId;
    private String validDescription;
    private Appointment validAppointment;
    
    /**
     * setUp() - Initializes common test data before each test method runs.
     * Creates an AppointmentService instance, future and past dates, and valid test data.
     */
    @BeforeEach
    public void setUp() {
        service = new AppointmentService();
        
        // Create a future date 1 day ahead of current system date/time
        futureDate = new Date(System.currentTimeMillis() + ONE_DAY_IN_MILLIS);
        
        // Create a past date 1 day previous to current system date/time
        pastDate = new Date(System.currentTimeMillis() - ONE_DAY_IN_MILLIS);
        
        validId = "APT001";
        validDescription = "Team meeting";
        validAppointment = new Appointment(validId, futureDate, validDescription);
    }
    
    @Test
    public void testAddAppointment_validAppointment_success() {
        service.addAppointment(validAppointment);

        // Verify that the appointment was added and can be retrieved by using the helper method getAppointment() 
        // which is not tested directly or used at this time other than testing but used to verify add, delete and update operations
        assertEquals(validAppointment, service.getAppointment(validId));
    }
    
    @Test
    public void testAddAppointment_nullAppointment_throws() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(null);
        });
        assertEquals("appointment must not be null", exception.getMessage());
    }
    
    @Test
    public void testAddAppointment_duplicateId_throws() {
        service.addAppointment(validAppointment);
        Appointment duplicate = new Appointment(validId, futureDate, "Different description");
        
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            service.addAppointment(duplicate);
        });
        assertEquals("appointment with id " + validId + " already exists", exception.getMessage());
    }
    
    @Test
    public void testDeleteAppointment_validId_success() {
        service.addAppointment(validAppointment);
        service.deleteAppointment(validId);
        
        // Verify appointment is actually deleted by checking getAppointment returns null
        assertNull(service.getAppointment(validId));
    }
    
    @Test
    public void testDeleteAppointment_nullId_throws() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment(null);
        });
        assertEquals("appointmentId must not be null", exception.getMessage());
    }
    
    @Test
    public void testDeleteAppointment_nonExistentId_throws() {
        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            service.deleteAppointment("NONEXISTENT");
        });
        assertEquals("appointmentId not found: NONEXISTENT", exception.getMessage());
    }

    
    @Test
    public void testAddDelete_fullLifecycle() {
        // Add appointment
        service.addAppointment(validAppointment);
        
        // Update appointment
        Date newDate = new Date(System.currentTimeMillis() + (2 * ONE_DAY_IN_MILLIS));
        String newDescription = "Updated meeting";
        
        // Delete appointment
        service.deleteAppointment(validId);
        
        // Verify it's actually deleted by checking getAppointment returns null
        assertNull(service.getAppointment(validId));
    }
}
