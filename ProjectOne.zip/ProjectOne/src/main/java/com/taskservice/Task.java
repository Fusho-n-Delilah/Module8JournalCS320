/**
 * Task.java
 * Description: Task data model with validation for fields.
 * Author: Alec Feldhaus
 */

package com.taskservice;

public class Task {
    private String taskId;
    private String name;
    private String description;

    public Task(String taskId, String name, String description) {
        validateId(taskId);
        this.taskId = taskId;
        setName(name);
        setDescription(description);
    }
    public String validateId(String id) {
        if (id == null) {
            throw new IllegalArgumentException("taskId must not be null");
        }
        String trimmed = id.trim();
        if (trimmed.isEmpty()) {
            throw new IllegalArgumentException("taskId is required");
        }
        if (trimmed.length() > 10) {
            throw new IllegalArgumentException("taskId must be less than 10 characters");
        }
        return trimmed;
    }   

    public String getTaskId() {
        return taskId;
    }
    public String getName() {
        return name;
    }
    public String getDescription() {
        return description;
    }
    public void setName(String name) {
        if(name == null) {
            throw new IllegalArgumentException("name must not be null");
        }
        String trimmed = name.trim();
        if(trimmed.isEmpty()) {
            throw new IllegalArgumentException("name is required");
        }
        if(trimmed.length() > 20) {
            throw new IllegalArgumentException("name must be less than 20 characters");
        }
        this.name = name;
    }
    public void setDescription(String description) {
        if(description == null) {
            throw new IllegalArgumentException("description must not be null");
        }
        String trimmed = description.trim();
        if(trimmed.isEmpty()) {
            throw new IllegalArgumentException("description is required");
        }
        if(trimmed.length() > 50) {
            throw new IllegalArgumentException("description must be less than 50 characters");
        }
        this.description = description;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Task)) return false;
        Task t = (Task) o;
        return taskId.equals(t.taskId) && name.equals(t.name) && description.equals(t.description);
    }

    @Override
    public int hashCode() {
        return taskId.hashCode() + name.hashCode() + description.hashCode();
    }
    
}
