/**
 * TaskService.java
 * Description: In-memory TaskService providing add, delete and update operations.
 * Author: Alec Feldhaus
 */

package com.taskservice;

import java.util.HashMap;
import java.util.Map;

public class TaskService {

    private final Map<String, Task> tasks = new HashMap<>();

     /**
     * Adds a new task. task must be non-null and its id must be unique.
     */
    public void addTask(Task task) {
        if (task == null) {
            throw new IllegalArgumentException("task must not be null");
        }
        String taskId = task.getTaskId();
        if (tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("task with id " + taskId + " already exists");
        }
        tasks.put(taskId, task);
    }

    /**
     * Deletes a task by id.
     */
    public void deleteTask(String taskId) {
        if(taskId == null) {
            throw new IllegalArgumentException("taskId must not be null");
        }
        if(!tasks.containsKey(taskId)) {
            throw new IllegalArgumentException("taskId not found: " + taskId);
        }
        tasks.remove(taskId);
    }

    /**
     * Updates all updatable fields for the task with the given id.
     * pass a null name or description to leave it unchanged.
     * @param taskId
     * @param name
     * @param description
     */
    public void updateTask(String taskId, String name, String description) {
        if(taskId == null) {
            throw new IllegalArgumentException("taskId must not be null");
        }
        Task t = tasks.get(taskId);
        if(t == null) {
            throw new IllegalArgumentException("taskId not found: " + taskId);
        }
        t.setName(name == null ? t.getName() : name);
        t.setDescription(description == null ? t.getDescription() : description);
        
    }

    // Helper for tests and inspection
    public Task getTask(String taskId) {
        return tasks.get(taskId);
    }
}
