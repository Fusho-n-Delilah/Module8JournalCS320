/**
 * Contact.java
 * Description: Contact data model with validation for fields.
 * Author: Alec Feldhaus
 */

package com.contactservice;

import java.util.Objects;

/**
 * Contact data model
 */
public class Contact {
    private final String contactId;
    private String firstName;
    private String lastName;
    private String phone;
    private String address;

    /**
     * Creates a new Contact with the given fields. contactId must be non-null and unique. 
     * firstName, lastName, phone and address must not be null and pass validation in the setters.
     * @param contactId
     * @param firstName
     * @param lastName
     * @param phone
     * @param address
     */
    public Contact(String contactId, String firstName, String lastName, String phone, String address) {
        validateId(contactId);
        this.contactId = contactId;
        setFirstName(firstName);
        setLastName(lastName);
        setPhone(phone);
        setAddress(address);
    }

    /**
     * Validates the contactId field.
     * @param id
     */
    private void validateId(String id) {
        if (id == null) {
            throw new IllegalArgumentException("contactId must not be null");
        }
        String trimmed = id.trim();
        if (trimmed.isEmpty()) {
            throw new IllegalArgumentException("contactId must not be empty");
        }
        if (trimmed.length() > 10) {
            throw new IllegalArgumentException("contactId must be at most 10 characters");
        }
    }

    public String getContactId() {
        return contactId;
    }

    public String getFirstName() {
        return firstName;
    }

    /**
     * Sets the firstName field. firstName must not be null, empty or longer than 10 characters.
     * @param firstName
     */
    public void setFirstName(String firstName) {
        if (firstName == null) {
            throw new IllegalArgumentException("firstName must not be null");
        }
        String trimmed = firstName.trim();
        if (trimmed.isEmpty()) {
            throw new IllegalArgumentException("firstName must not be empty");
        }
        if (trimmed.length() > 10) {
            throw new IllegalArgumentException("firstName must be 10 characters or less");
        }
        this.firstName = trimmed;
    }

    public String getLastName() {
        return lastName;
    }

    /**
     * Sets the lastName field. lastName must not be null, empty or longer than 10 characters.
     * @param lastName
     */
    public void setLastName(String lastName) {
        if (lastName == null) {
            throw new IllegalArgumentException("lastName must not be null");
        }
        String trimmed = lastName.trim();
        if (trimmed.isEmpty()) {
            throw new IllegalArgumentException("lastName must not be empty");
        }
        if (trimmed.length() > 10) {
            throw new IllegalArgumentException("lastName must be 10 characters or less");
        }
        this.lastName = trimmed;
    }

    public String getPhone() {
        return phone;
    }

    /**
     * Sets the phone field. phone must not be null and must be exactly 10 digits.
     * @param phone
     */
    public void setPhone(String phone) {
        if (phone == null) {
            throw new IllegalArgumentException("phone must not be null");
        }
        String trimmed = phone.trim();
        if (trimmed.isEmpty()) {
            throw new IllegalArgumentException("phone must not be empty");
        }
        if (!trimmed.matches("\\d{10}")) {
            throw new IllegalArgumentException("phone must be exactly 10 digits");
        }
        this.phone = trimmed;
    }

    public String getAddress() {
        return address;
    }

    /**
     * Sets the address field. address must not be null, empty or longer than 30 characters.
     * @param address
     */
    public void setAddress(String address) {
        if (address == null) {
            throw new IllegalArgumentException("address must not be null");
        }
        String trimmed = address.trim();
        if (trimmed.isEmpty()) {
            throw new IllegalArgumentException("address must not be empty");
        }
        if (trimmed.length() > 30) {
            throw new IllegalArgumentException("address must be 30 characters or less");
        }
        this.address = trimmed;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (o == null || getClass() != o.getClass()) return false;
        Contact contact = (Contact) o;
        return contactId.equals(contact.contactId) && Objects.equals(firstName, contact.firstName)
                && Objects.equals(lastName, contact.lastName) && Objects.equals(phone, contact.phone)
                && Objects.equals(address, contact.address);
    }

    @Override
    public int hashCode() {
        return Objects.hash(contactId, firstName, lastName, phone, address);
    }
}
