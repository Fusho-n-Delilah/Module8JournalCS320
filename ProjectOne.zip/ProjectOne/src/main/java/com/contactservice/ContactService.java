/**
 * ContactService.java
 * Description: In-memory ContactService providing add, delete and update operations.
 * Author: Alec Feldhaus
 */

package com.contactservice;

import java.util.HashMap;
import java.util.Map;
import java.util.NoSuchElementException;

/**
 * In-memory ContactService providing add, delete and update operations.
 */
public class ContactService {
    private final Map<String, Contact> contacts = new HashMap<>();

    /**
     * Adds a new contact. contact must be non-null and its id must be unique.
     * @param contact
     */
    public void addContact(Contact contact) {
        if (contact == null) {
            throw new IllegalArgumentException("contact must not be null");
        }
        String id = contact.getContactId();
        if (contacts.containsKey(id)) {
            throw new IllegalArgumentException("contactId already exists: " + id);
        }
        contacts.put(id, contact);
    }

    /**
     * Deletes a contact by id.
     * @param contactId
     */
    public void deleteContact(String contactId) {
        if (contactId == null) {
            throw new IllegalArgumentException("contactId must not be null");
        }
        if (!contacts.containsKey(contactId)) {
            throw new NoSuchElementException("contactId not found: " + contactId);
        }
        contacts.remove(contactId);
    }

    /**
     * Updates all updatable fields for the contact with the given id.
     * pass null parameters to leave fields unchanged.
     * @param contactId
     * @param firstName
     * @param lastName
     * @param phone
     * @param address
     */
    public void updateContact(String contactId, String firstName, String lastName, String phone, String address) {
        if (contactId == null) {
            throw new IllegalArgumentException("contactId must not be null");
        }
        Contact c = contacts.get(contactId);
        if (c == null) {
            throw new NoSuchElementException("contactId not found: " + contactId);
        }
        // Setters cover empty strings
        c.setFirstName(firstName == null ? c.getFirstName() : firstName);
        c.setLastName(lastName == null ? c.getLastName() : lastName);
        c.setPhone(phone == null ? c.getPhone() : phone);
        c.setAddress(address == null ? c.getAddress() : address);
    }

    // Helper for tests and inspection
    public Contact getContact(String contactId) {
        return contacts.get(contactId);
    }
}
