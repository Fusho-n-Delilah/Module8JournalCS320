/**
 * AppointmentService.java
 * Description: In-memory AppointmentService providing add, delete and update operations.
 * Author: Alec Feldhaus
 * Date: 2024-02-07
 */

package com.appointmentservice;

import java.util.HashMap;
import java.util.Map;

public class AppointmentService {
    private final Map<String, Appointment> appointments = new HashMap<>();

     /**
     * Adds a new appointment. appointment must be non-null and its id must be unique.
     * @param appointment
     */
    public void addAppointment(Appointment appointment) {
        if (appointment == null) {
            throw new IllegalArgumentException("appointment must not be null");
        }
        String appointmentId = appointment.getAppointmentId();
        if (appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("appointment with id " + appointmentId + " already exists");
        }
        appointments.put(appointmentId, appointment);
    }

    /**
     * Deletes an appointment by id.
     * @param appointmentId
     */
    public void deleteAppointment(String appointmentId) {
        if(appointmentId == null) {
            throw new IllegalArgumentException("appointmentId must not be null");
        }
        if(!appointments.containsKey(appointmentId)) {
            throw new IllegalArgumentException("appointmentId not found: " + appointmentId);
        }
        appointments.remove(appointmentId);
    }

    // Helper for tests and inspection
    public Appointment getAppointment(String appointmentId) {
        return appointments.get(appointmentId);
    }
}
