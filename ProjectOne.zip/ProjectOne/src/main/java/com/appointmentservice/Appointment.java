/**
 * Appointment.java
 * Description: Appointment data model with validation for fields.
 * Author: Alec Feldhaus
 * Date: 2024-02-07
 */

package com.appointmentservice;

import java.util.Date;

public class Appointment {
    private String appointmentId;
    private Date date;
    private String description;

    public Appointment(String appointmentId, Date date, String description) {
        validateId(appointmentId);
        this.appointmentId = appointmentId;
        setDate(date);
        setDescription(description);
    }

    public String validateId(String id) {
        if (id == null) {
            throw new IllegalArgumentException("appointmentId must not be null");
        }
        String trimmed = id.trim();
        if (trimmed.isEmpty()) {
            throw new IllegalArgumentException("appointmentId is required");
        }
        if (trimmed.length() > 10) {
            throw new IllegalArgumentException("appointmentId must be less than 10 characters");
        }
        return trimmed;
    }

    public String getAppointmentId() {
        return appointmentId;
    }

    public Date getDate() {
        return date;
    }

    public String getDescription() {
        return description;
    }

    public void setDate(Date date) {
        if (date == null) {
            throw new IllegalArgumentException("date must not be null");
        }
        if (date.before(new Date())) {
            throw new IllegalArgumentException("date must be in the future");
        }
        this.date = date;
    }

    public void setDescription(String description) {
        if (description == null) {
            throw new IllegalArgumentException("description must not be null");
        }
        String trimmed = description.trim();
        if (trimmed.isEmpty()) {
            throw new IllegalArgumentException("description is required");
        }
        if (trimmed.length() > 50) {
            throw new IllegalArgumentException("description must be less than 50 characters");
        }
        this.description = description;
    }

    @Override
    public boolean equals(Object o) {
        if (this == o) return true;
        if (!(o instanceof Appointment)) return false;
        Appointment a = (Appointment) o;
        return appointmentId.equals(a.appointmentId) &&
               date.equals(a.date) &&
               description.equals(a.description);
    }

    @Override
    public int hashCode() {
        return appointmentId.hashCode() + date.hashCode() + description.hashCode();
    }
}
